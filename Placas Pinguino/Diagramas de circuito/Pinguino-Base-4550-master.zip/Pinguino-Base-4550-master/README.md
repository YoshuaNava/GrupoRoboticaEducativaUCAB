Pinguino Base 4550
=====================

Pinguino Base es una alternativa a la placa original del proyecto Pinguino
esta llama Pinguino-tiny4550, siendo '''Pinguino Base''' una mejora substancial
en cuanto a nivel electronico y a nivel de diseño. Siendo su objetivo principal
la capacidad de acoplar ''extensiones'', estas utiles a la hora de realizar
prototipos rapidos de proyectos.

Siendo este diseño muy influenciado en la placa Arduino, pero sin intentar ser
un clon de este, incluso no espera ser compatible pin a pin, con sus shields,
sin embargo se inspira en su arquitectura de hardware para el diseño de los
shields.