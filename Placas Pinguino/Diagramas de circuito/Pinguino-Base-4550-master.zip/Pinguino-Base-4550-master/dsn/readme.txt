Archivos de diseño
==================

Coloca una pequeña descripción de los archivos que incluyes como
parte del diseño. En la carpeta main puedes colocar los archivos
fuente originales y en "extra" formatos de intercambio como se
muestra en el siguiente ejemplo.

Archivos de diseño principal:

* main\Test.sch : Archivo fuente del diagráma eléctrico para Eagle.
* main\Test.brd : Archivo fuente de la tableta impresa para Eagle.

Archivos de diseño auxiliar:
* main\Test.pdf : PDF para impresión del diagrama eléctrico

